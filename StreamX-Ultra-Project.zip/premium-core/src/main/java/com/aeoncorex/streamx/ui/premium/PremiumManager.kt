package com.aeoncorex.streamx.ui.premium

import android.util.Log
import com.aeoncorex.streamx.data.FirestoreDb
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

object PremiumManager {

    private const val TAG            = "PremiumManager"
    private const val CACHE_DURATION = 3_600_000L
    private const val COLLECTION     = "users"
    private const val FIELD_PREMIUM  = "isPremium"
    private const val FIELD_EXPIRY   = "premiumExpiry"

    @Volatile private var cachedResult: Boolean? = null
    @Volatile private var cacheTime:    Long     = 0L

    suspend fun isPremium(): Boolean {
        val now = System.currentTimeMillis()
        cachedResult?.let { if (now - cacheTime < CACHE_DURATION) return it }
        return fetchFromFirestore().also { cachedResult = it; cacheTime = now }
    }

    fun isPremiumCached(): Boolean = cachedResult ?: false

    suspend fun grantPremium(uid: String, expiryMs: Long? = null) {
        try {
            val dataMap = mutableMapOf<String, Any>(FIELD_PREMIUM to true)
            if (expiryMs != null) dataMap[FIELD_EXPIRY] = expiryMs
            
            FirestoreDb.instance.collection(COLLECTION).document(uid)
                .set(dataMap, SetOptions.merge()).await()
            
            cachedResult = true; cacheTime = System.currentTimeMillis()
        } catch (e: Exception) { 
            Log.e(TAG, "grantPremium: ${e.message}") 
        }
    }

    suspend fun revokePremium(uid: String) {
        try {
            FirestoreDb.instance.collection(COLLECTION).document(uid)
                .update(FIELD_PREMIUM, false).await()
            invalidateCache()
        } catch (e: Exception) { 
            Log.e(TAG, "revokePremium: ${e.message}") 
        }
    }

    fun invalidateCache() { 
        cachedResult = null
        cacheTime = 0L 
    }

    private suspend fun fetchFromFirestore(): Boolean {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return false
        return try {
            val doc = FirestoreDb.instance.collection(COLLECTION).document(uid).get().await()
            val ok  = doc.getBoolean(FIELD_PREMIUM) ?: false
            if (!ok) return false
            
            val exp = doc.getLong(FIELD_EXPIRY)
            if (exp != null && System.currentTimeMillis() > exp) { 
                revokePremium(uid)
                return false 
            }
            true
        } catch (e: Exception) { 
            Log.e(TAG, "fetchFromFirestore: ${e.message}")
            false 
        }
    }
}
