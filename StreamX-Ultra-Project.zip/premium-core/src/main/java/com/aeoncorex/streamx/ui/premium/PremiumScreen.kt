package com.aeoncorex.streamx.ui.premium

import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// ── Design tokens ─────────────────────────────────────────────────
private val Purple      = Color(0xFF7C4DFF)
private val PurpleLight = Color(0xFFB388FF)
private val Gold        = Color(0xFFFFD700)
private val GoldLight   = Color(0xFFFFE57F)
private val DarkBg      = Color(0xFF0A0818)
private val CardBg      = Color(0xFF12102A)

// ── Gumroad product URLs ──────────────────────────────────────────
private const val GUMROAD_MONTHLY_URL  = "https://aeoncore.gumroad.com/l/hrsxee"
private const val GUMROAD_YEARLY_URL   = "https://aeoncore.gumroad.com/l/kqjrjl"

// Deep link that Gumroad redirects to after successful payment
private const val SUCCESS_SCHEME = "streamx://payment/success"

/**
 * Builds the Gumroad checkout URL with:
 *  - uid embedded as custom field (for webhook lookup)
 *  - success_url set to deep link (for automatic app redirect)
 *  - wanted=true to go directly to checkout (skip product description page)
 */
private fun buildGumroadUrl(plan: String, uid: String): String {
    val baseUrl    = if (plan == "yearly") GUMROAD_YEARLY_URL else GUMROAD_MONTHLY_URL
    val successUrl = java.net.URLEncoder.encode("$SUCCESS_SCHEME?plan=$plan", "UTF-8")
    val uidEncoded = java.net.URLEncoder.encode(uid, "UTF-8")
    return "$baseUrl?wanted=true" +
           "&custom_fields[uid]=$uidEncoded" +
           "&success_url=$successUrl"
}

// Render backend URL for license key verification
private val VERIFY_URL get() = try {
    val clazz = Class.forName("com.aeoncorex.streamx.BuildConfig")
    "${clazz.getField("BACKEND_BASE_URL").get(null)}/api/verify-premium"
} catch (_: Exception) { "https://streamx-backend-9wlt.onrender.com/api/verify-premium" }

// ═══════════════════════════════════════════════════════════════════
//  PremiumScreen
// ═══════════════════════════════════════════════════════════════════
@Composable
fun PremiumScreen(navController: NavController) {
    val context = LocalContext.current
    val scope   = rememberCoroutineScope()

    var isPremium       by remember { mutableStateOf(false) }
    var checkingStatus  by remember { mutableStateOf(true) }
    var selectedPlan    by remember { mutableStateOf("yearly") }  // default yearly (better value)
    var isVerifying     by remember { mutableStateOf(false) }
    var showKeyDialog   by remember { mutableStateOf(false) }
    var licenseKey      by remember { mutableStateOf("") }
    var verifyError     by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        isPremium      = PremiumManager.isPremium()
        checkingStatus = false
    }

    // Re-check when returning from in-app browser (after payment)
    LaunchedEffect(Unit) {
        delay(3000)
        repeat(10) {
            delay(5000)
            val fresh = PremiumManager.isPremium()
            if (fresh && !isPremium) { isPremium = true; return@repeat }
        }
    }

    BackHandler { navController.popBackStack() }

    // ── License Key Dialog ────────────────────────────────────────
    if (showKeyDialog) {
        AlertDialog(
            onDismissRequest = { showKeyDialog = false; verifyError = null },
            containerColor   = CardBg,
            shape            = RoundedCornerShape(20.dp),
            title = {
                Text("Enter License Key", color = Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 18.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("After purchasing on Gumroad, enter your license key here.",
                        color = Color.Gray, fontSize = 13.sp)
                    OutlinedTextField(
                        value         = licenseKey,
                        onValueChange = { licenseKey = it.uppercase(); verifyError = null },
                        placeholder   = { Text("XXXX-XXXX-XXXX-XXXX", color = Color.Gray) },
                        singleLine    = true,
                        colors        = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor   = Purple,
                            unfocusedBorderColor = Color.White.copy(0.2f),
                            focusedTextColor     = Color.White,
                            unfocusedTextColor   = Color.White,
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (verifyError != null) {
                        Text(verifyError!!, color = Color(0xFFF43F5E), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick  = {
                        scope.launch {
                            isVerifying = true
                            verifyError = null
                            val result = verifyLicenseKey(licenseKey.trim(), selectedPlan)
                            isVerifying = false
                            if (result == null) {
                                isPremium = true
                                showKeyDialog = false
                                licenseKey = ""
                                PremiumManager.invalidateCache()
                            } else {
                                verifyError = result
                            }
                        }
                    },
                    enabled = licenseKey.length >= 8 && !isVerifying,
                    colors  = ButtonDefaults.buttonColors(containerColor = Purple),
                ) {
                    if (isVerifying) {
                        CircularProgressIndicator(color = Color.White,
                            modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Activate Premium")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showKeyDialog = false; verifyError = null }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(DarkBg, Color(0xFF0D0D20), Color(0xFF080818)))
    )) {
        Box(Modifier.size(300.dp).offset((-60).dp, (-60).dp)
            .background(Brush.radialGradient(listOf(Purple.copy(0.18f), Color.Transparent)), CircleShape))
        Box(Modifier.size(250.dp).align(Alignment.BottomEnd).offset(60.dp, 60.dp)
            .background(Brush.radialGradient(listOf(Gold.copy(0.10f), Color.Transparent)), CircleShape))

        when {
            checkingStatus -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Purple)
                }
            }
            isPremium -> PremiumActiveScreen { navController.popBackStack() }
            else -> {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

                    // ── Top bar ───────────────────────────────────
                    Row(
                        Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                        }
                        Text("StreamX Premium",
                            color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        Spacer(Modifier.size(48.dp))
                    }

                    // ── Hero ──────────────────────────────────────
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val pulse = rememberInfiniteTransition(label = "p")
                        val sc by pulse.animateFloat(0.92f, 1.08f,
                            infiniteRepeatable(tween(1800, easing = EaseInOutSine), RepeatMode.Reverse), "s")
                        Box(
                            Modifier.size(90.dp).scale(sc)
                                .background(Brush.radialGradient(listOf(Gold.copy(0.25f), Color.Transparent)), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.WorkspacePremium, null,
                                tint = Gold, modifier = Modifier.size(56.dp))
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Go Premium", color = Color.White,
                            fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(6.dp))
                        Text("Enjoy StreamX without any ads",
                            color = Color.Gray, fontSize = 15.sp, textAlign = TextAlign.Center)
                    }

                    Spacer(Modifier.height(28.dp))

                    // ── Features ──────────────────────────────────
                    Column(Modifier.padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PremiumFeatureRow(
                            icon  = Icons.Rounded.PublicOff,
                            color = Gold,
                            title = "Ad-Free Experience",
                            desc  = "Zero ads — no app-open ads, no pre-play ads. Pure uninterrupted streaming."
                        )
                        PremiumFeatureRow(
                            icon  = Icons.Rounded.VerifiedUser,
                            color = Purple,
                            title = "Support StreamX",
                            desc  = "Help keep StreamX free and running for everyone. More features coming soon."
                        )
                        PremiumFeatureRow(
                            icon  = Icons.Rounded.Update,
                            color = PurpleLight,
                            title = "Early Access to New Features",
                            desc  = "Premium members get priority access to all upcoming StreamX features."
                        )
                    }

                    Spacer(Modifier.height(28.dp))

                    // ── Plan selector ─────────────────────────────
                    Text("Choose Plan",
                        color = Color.White, fontWeight = FontWeight.Bold,
                        fontSize = 16.sp, modifier = Modifier.padding(horizontal = 20.dp))
                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PlanCard(
                            modifier     = Modifier.weight(1f),
                            title        = "Monthly",
                            price        = "$8.99",
                            period       = "/ month",
                            badge        = null,
                            isSelected   = selectedPlan == "monthly",
                            accentColor  = Purple,
                            onClick      = { selectedPlan = "monthly" }
                        )
                        PlanCard(
                            modifier     = Modifier.weight(1f),
                            title        = "Yearly",
                            price        = "$18.99",
                            period       = "/ year",
                            badge        = "SAVE 82%",
                            isSelected   = selectedPlan == "yearly",
                            accentColor  = Gold,
                            onClick      = { selectedPlan = "yearly" }
                        )
                    }

                    Spacer(Modifier.height(8.dp))
                    if (selectedPlan == "yearly") {
                        Text(
                            "That's just $1.58/month — billed as $18.99/year",
                            color = GoldLight, fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(Modifier.height(24.dp))

                    // ── Buttons ───────────────────────────────────
                    Column(Modifier.padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {

                        // ✅ Main CTA — opens Gumroad inside the app (InAppBrowserActivity)
                        Button(
                            onClick = {
                                val uid = FirebaseAuth.getInstance().currentUser?.uid ?: ""
                                val url = buildGumroadUrl(selectedPlan, uid)
                                val intent = Intent(context, InAppBrowserActivity::class.java).apply {
                                    putExtra(InAppBrowserActivity.EXTRA_URL,  url)
                                    putExtra(InAppBrowserActivity.EXTRA_PLAN, selectedPlan)
                                }
                                try {
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    // Fallback: open in Chrome if something goes wrong
                                    try {
                                        context.startActivity(
                                            Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                        )
                                    } catch (_: Exception) {
                                        Toast.makeText(context, "Cannot open browser", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape    = RoundedCornerShape(16.dp),
                            colors   = ButtonDefaults.buttonColors(
                                containerColor = if (selectedPlan == "yearly") Gold else Purple
                            )
                        ) {
                            Icon(Icons.Rounded.ShoppingCart, null,
                                tint = Color.Black, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Subscribe ${if (selectedPlan == "yearly") "Yearly — $18.99" else "Monthly — $8.99"}",
                                color      = Color.Black,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize   = 15.sp
                            )
                        }

                        // Already purchased — enter key
                        OutlinedButton(
                            onClick  = { showKeyDialog = true },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape    = RoundedCornerShape(16.dp),
                            border   = androidx.compose.foundation.BorderStroke(
                                1.dp, Purple.copy(0.5f)
                            ),
                            colors   = ButtonDefaults.outlinedButtonColors(contentColor = Purple)
                        ) {
                            Icon(Icons.Rounded.VpnKey, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("I have a license key", fontSize = 14.sp)
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // ── Fine print ────────────────────────────────
                    Text(
                        "Secure payment via Gumroad • Cancel anytime in your Gumroad account\n" +
                        "Premium activates within seconds after payment.",
                        color     = Color.Gray.copy(0.55f),
                        fontSize  = 10.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 15.sp,
                        modifier  = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                    )
                    Spacer(Modifier.height(40.dp))
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  PlanCard
// ═══════════════════════════════════════════════════════════════════
@Composable
private fun PlanCard(
    modifier:    Modifier,
    title:       String,
    price:       String,
    period:      String,
    badge:       String?,
    isSelected:  Boolean,
    accentColor: Color,
    onClick:     () -> Unit,
) {
    val border = if (isSelected) 2.dp else 1.dp
    val borderCol = if (isSelected) accentColor else Color.White.copy(0.1f)
    val bg = if (isSelected) accentColor.copy(0.12f) else CardBg

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .border(border, borderCol, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(16.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (badge != null) {
                Text(badge, color = Color.Black, fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier
                        .background(accentColor, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp))
                Spacer(Modifier.height(6.dp))
            } else {
                Spacer(Modifier.height(17.dp))
            }
            Text(title, color = Color.White.copy(if (isSelected) 1f else 0.7f),
                fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text(price, color = if (isSelected) accentColor else Color.White,
                fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            Text(period, color = Color.Gray, fontSize = 11.sp)
        }
        if (isSelected) {
            Icon(Icons.Rounded.CheckCircle, null,
                tint = accentColor,
                modifier = Modifier.size(18.dp).align(Alignment.TopEnd))
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  Feature row
// ═══════════════════════════════════════════════════════════════════
@Composable
private fun PremiumFeatureRow(
    icon:  ImageVector,
    color: Color,
    title: String,
    desc:  String,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(40.dp)
                .background(color.copy(0.12f), RoundedCornerShape(12.dp))
                .border(1.dp, color.copy(0.25f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = color, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(desc,  color = Color.Gray,  fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  Premium Active Screen
// ═══════════════════════════════════════════════════════════════════
@Composable
private fun PremiumActiveScreen(onBack: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)) {
            val pulse = rememberInfiniteTransition(label = "p")
            val sc by pulse.animateFloat(0.95f, 1.05f,
                infiniteRepeatable(tween(1500), RepeatMode.Reverse), "s")
            Box(Modifier.size(100.dp).scale(sc)
                .background(Brush.radialGradient(listOf(Gold.copy(0.25f), Color.Transparent)), CircleShape),
                contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.WorkspacePremium, null, tint = Gold, modifier = Modifier.size(56.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text("You're Premium! 🎉", color = Color.White,
                fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            Text("Ad-free experience is active.\nEnjoy uninterrupted streaming!",
                color = Color.LightGray, fontSize = 15.sp,
                textAlign = TextAlign.Center, lineHeight = 22.sp)
            Spacer(Modifier.height(32.dp))
            Button(onClick = onBack,
                colors   = ButtonDefaults.buttonColors(containerColor = Purple),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape    = RoundedCornerShape(14.dp)) {
                Text("Start Watching", color = Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  License key verifier — calls Vercel backend
// ═══════════════════════════════════════════════════════════════════
private suspend fun verifyLicenseKey(key: String, plan: String): String? =
    withContext(Dispatchers.IO) {
        try {
            val idToken = FirebaseAuth.getInstance().currentUser
                ?.getIdToken(false)?.await()?.token
                ?: return@withContext "Please sign in first"

            val body = JSONObject().apply {
                put("licenseKey", key)
                put("plan", plan)
            }.toString()

            val conn = (URL(VERIFY_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type",  "application/json")
                setRequestProperty("Authorization", "Bearer $idToken")
                doOutput        = true
                connectTimeout  = 12_000
                readTimeout     = 15_000
                outputStream.use { it.write(body.toByteArray()) }
            }

            val code = conn.responseCode
            val resp = try {
                conn.inputStream.bufferedReader().use { it.readText() }
            } catch (_: Exception) {
                conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            }

            if (code == 200) null  // success
            else JSONObject(resp).optString("message", "Invalid license key")

        } catch (e: Exception) {
            Log.e("PremiumScreen", "verifyKey: ${e.message}")
            "Verification failed. Check your connection."
        }
    }
