package com.aeoncorex.streamx.ui.premium

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat

// ── Palette ────────────────────────────────────────────────────────
private val C_BG        = Color(0xFF06060F)   // near-black canvas
private val C_NAV       = Color(0xFF0C0C1A)   // nav bar surface
private val C_PURPLE    = Color(0xFF8B5CF6)   // violet accent
private val C_CYAN      = Color(0xFF06B6D4)   // cyan accent
private val C_GREEN     = Color(0xFF10B981)   // secure green
private val C_RED       = Color(0xFFEF4444)   // close red
private val C_GLASS     = Color(0x12FFFFFF)   // frosted glass fill
private val C_BORDER    = Color(0x1AFFFFFF)   // glass border

class InAppBrowserActivity : ComponentActivity() {

    companion object {
        const val EXTRA_URL  = "extra_url"
        const val EXTRA_PLAN = "extra_plan"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // ✅ FIX 1 — edge-to-edge: removes white status bar gap
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // ✅ FIX 2 — keep status bar icons white (light text on dark bg)
        WindowCompat.getInsetsController(window, window.decorView)
            .isAppearanceLightStatusBars = false

        // ✅ FIX 3 — kill the white flash on launch.
        // The Window's default background is white, so before Compose's
        // first frame (and before the WebView paints its own background)
        // the system briefly shows the raw window background → white flash.
        // Setting it here, before setContent, removes that gap entirely.
        window.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#FF06060F"))
        )

        val url  = intent.getStringExtra(EXTRA_URL)  ?: run { finish(); return }
        val plan = intent.getStringExtra(EXTRA_PLAN) ?: "monthly"

        setContent {
            InAppBrowserScreen(
                initialUrl = url,
                onClose    = { finish() },
                onSuccess  = { successUrl ->
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(successUrl)))
                    finish()
                }
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  Screen
// ═══════════════════════════════════════════════════════════════════
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun InAppBrowserScreen(
    initialUrl : String,
    onClose    : () -> Unit,
    onSuccess  : (String) -> Unit,
) {
    var progress    by remember { mutableFloatStateOf(0f) }
    var isLoading   by remember { mutableStateOf(true) }
    var currentHost by remember { mutableStateOf("") }
    var isSecure    by remember { mutableStateOf(true) }
    var webViewRef  by remember { mutableStateOf<WebView?>(null) }
    var canGoBack   by remember { mutableStateOf(false) }

    BackHandler {
        val wv = webViewRef
        if (wv != null && wv.canGoBack()) wv.goBack() else onClose()
    }

    val inf = rememberInfiniteTransition(label = "br")

    // neon pulse
    val pulse by inf.animateFloat(
        .35f, 1f,
        infiniteRepeatable(tween(1800, easing = EaseInOutSine), RepeatMode.Reverse), "pulse"
    )
    // spinner
    val spinCw by inf.animateFloat(
        0f, 360f, infiniteRepeatable(tween(1600, easing = LinearEasing)), "cw"
    )
    val spinCcw by inf.animateFloat(
        360f, 0f, infiniteRepeatable(tween(1100, easing = LinearEasing)), "ccw"
    )
    // progress shimmer
    val shimmer by inf.animateFloat(
        -500f, 1400f, infiniteRepeatable(tween(1000, easing = LinearEasing)), "sh"
    )
    // live dot
    val dotPulse by inf.animateFloat(
        .3f, 1f,
        infiniteRepeatable(tween(800, easing = EaseInOutSine), RepeatMode.Reverse), "dp"
    )

    // ── Root — full-screen dark canvas ────────────────────────────
    Box(
        Modifier
            .fillMaxSize()
            .background(C_BG)
            // ✅ FIX 3 — extend behind system bars so nothing is white
            .windowInsetsPadding(WindowInsets(0))
    ) {
        Column(Modifier.fillMaxSize()) {

            // ════════════════════════════════════════════════════
            //  NAV BAR — draws into status bar area via statusBarsPadding
            // ════════════════════════════════════════════════════
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(C_NAV)
                    .statusBarsPadding()     // ← pushes content below status bar,
                                             //   but C_NAV fills behind it
                    .drawBehind {
                        // glowing bottom separator
                        val y = size.height
                        drawLine(
                            brush = Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    C_PURPLE.copy(pulse * .8f),
                                    C_CYAN.copy(pulse),
                                    C_PURPLE.copy(pulse * .8f),
                                    Color.Transparent
                                )
                            ),
                            start       = Offset(0f, y),
                            end         = Offset(size.width, y),
                            strokeWidth = 1.2f
                        )
                    }
            ) {
                // ── Controls row ──────────────────────────────
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {

                    // Back — always clickable:
                    //   WebView history আছে → goBack | নেই → Activity close
                    GlassButton(
                        onClick = {
                            val wv = webViewRef
                            if (wv?.canGoBack() == true) wv.goBack() else onClose()
                        },
                        enabled = true,
                    ) {
                        Icon(
                            Icons.Rounded.ArrowBack, null,
                            tint     = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Address pill
                    Row(
                        Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(C_GLASS)
                            .border(
                                1.dp,
                                Brush.horizontalGradient(
                                    listOf(
                                        if (isSecure) C_GREEN.copy(.5f) else Color.Gray.copy(.3f),
                                        C_BORDER,
                                        C_PURPLE.copy(.4f)
                                    )
                                ),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        // lock glow
                        Box(
                            Modifier
                                .size(14.dp)
                                .drawBehind {
                                    if (isSecure) drawCircle(
                                        C_GREEN.copy(.22f),
                                        radius = size.minDimension * 1.6f
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Rounded.Lock, null,
                                tint     = if (isSecure) C_GREEN else Color.Gray,
                                modifier = Modifier.size(11.dp)
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(
                            currentHost.ifEmpty { "Loading…" },
                            color         = Color.White.copy(.85f),
                            fontSize      = 13.sp,
                            fontWeight    = FontWeight.Medium,
                            maxLines      = 1,
                            overflow      = TextOverflow.Ellipsis
                        )
                    }

                    // Reload
                    GlassButton(onClick = { webViewRef?.reload() }, enabled = !isLoading) {
                        Icon(
                            Icons.Rounded.Refresh, null,
                            tint     = Color.White.copy(if (!isLoading) .75f else .3f),
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    // Close
                    Box(
                        Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(C_RED.copy(.12f))
                            .border(1.dp, C_RED.copy(pulse * .5f), RoundedCornerShape(10.dp))
                            .clickable { onClose() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.Close, null,
                            tint     = C_RED.copy(.9f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // ── Progress bar ──────────────────────────────
                ProgressBar(
                    isLoading = isLoading,
                    progress  = progress,
                    shimmer   = shimmer
                )
            }

            // ── Secure badge strip ────────────────────────────
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(C_GREEN.copy(.05f), C_CYAN.copy(.03f), C_PURPLE.copy(.05f))
                        )
                    )
                    .drawBehind {
                        drawLine(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, C_GREEN.copy(.22f), Color.Transparent)
                            ),
                            start = Offset(0f, size.height),
                            end   = Offset(size.width, size.height),
                            strokeWidth = .8f
                        )
                    }
                    .padding(vertical = 5.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                // pulsing dot
                Box(
                    Modifier
                        .size(6.dp)
                        .drawBehind { drawCircle(C_GREEN.copy(dotPulse * .35f), size.minDimension * 2f) }
                        .background(C_GREEN.copy(dotPulse), CircleShape)
                )
                Spacer(Modifier.width(7.dp))
                Text(
                    "SECURE PAYMENT  ·  SSL ENCRYPTED  ·  GUMROAD",
                    color         = C_GREEN.copy(.68f),
                    fontSize      = 9.sp,
                    fontWeight    = FontWeight.Bold,
                    letterSpacing = .8.sp
                )
            }

            // ── WebView + Loading Overlay ─────────────────────
            WebViewBox(
                modifier      = Modifier.weight(1f).fillMaxWidth(),
                initialUrl    = initialUrl,
                isLoading     = isLoading,
                progress      = progress,
                currentHost   = currentHost,
                spinCw        = spinCw,
                spinCcw       = spinCcw,
                pulse         = pulse,
                onSuccess     = onSuccess,
                onStateChange = { wv, loading, secure, host, goBack ->
                    webViewRef  = wv
                    isLoading   = loading
                    isSecure    = secure
                    currentHost = host
                    canGoBack   = goBack
                },
                onProgress = { p ->
                    progress  = p
                    isLoading = p < 1f
                }
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  ProgressBar — extracted to break ColumnScope implicit receiver
//  (fixes: ColumnScope.AnimatedVisibility cannot be called in BoxScope)
// ═══════════════════════════════════════════════════════════════════
@Composable
private fun ProgressBar(
    isLoading : Boolean,
    progress  : Float,
    shimmer   : Float,
) {
    // This function has NO outer ColumnScope, so AnimatedVisibility
    // resolves to the top-level overload — no compile error.
    Box(
        Modifier
            .fillMaxWidth()
            .height(2.dp)
            .background(Color.White.copy(.04f))
    ) {
        AnimatedVisibility(
            visible = isLoading,
            enter   = fadeIn(),
            exit    = fadeOut(tween(400))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progress.coerceIn(.02f, 1f))
                    .drawBehind {
                        // gradient fill
                        drawRect(
                            Brush.horizontalGradient(
                                listOf(C_PURPLE, C_CYAN, C_PURPLE.copy(.7f))
                            )
                        )
                        // shimmer sweep
                        drawRect(
                            Brush.linearGradient(
                                listOf(
                                    Color.Transparent,
                                    Color.White.copy(.6f),
                                    Color.Transparent
                                ),
                                start = Offset(shimmer, 0f),
                                end   = Offset(shimmer + 180f, size.height)
                            )
                        )
                        // glowing tip
                        drawCircle(
                            Brush.radialGradient(listOf(C_CYAN, Color.Transparent)),
                            radius = 6f,
                            center = Offset(size.width, size.height / 2f)
                        )
                    }
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  WebViewBox — extracted to break ColumnScope implicit receiver
//  Contains the WebView + full-screen loading overlay.
//  AnimatedVisibility here is top-level (no ColumnScope in context).
// ═══════════════════════════════════════════════════════════════════
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun WebViewBox(
    modifier      : Modifier,
    initialUrl    : String,
    isLoading     : Boolean,
    progress      : Float,
    currentHost   : String,
    spinCw        : Float,
    spinCcw       : Float,
    pulse         : Float,
    onSuccess     : (String) -> Unit,
    onStateChange : (WebView?, Boolean, Boolean, String, Boolean) -> Unit,
    onProgress    : (Float) -> Unit,
) {
    Box(modifier) {

        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory  = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    // ✅ FIX 4 — WebView paints WHITE by default until the page's
                    // own CSS background loads. On slow connections (or before
                    // Gumroad's stylesheet applies) that shows as a white flash/
                    // gap. Setting it dark up front removes the flash completely.
                    setBackgroundColor(android.graphics.Color.parseColor("#FF06060F"))
                    settings.apply {
                        @Suppress("DEPRECATION")
                        javaScriptEnabled              = true
                        domStorageEnabled              = true
                        loadWithOverviewMode           = true
                        useWideViewPort                = true
                        setSupportZoom(true)
                        builtInZoomControls            = true
                        displayZoomControls            = false
                        setSupportMultipleWindows(true)
                        javaScriptCanOpenWindowsAutomatically = true
                        userAgentString =
                            "Mozilla/5.0 (Linux; Android 14; Pixel 8) " +
                            "AppleWebKit/537.36 (KHTML, like Gecko) " +
                            "Chrome/124.0.0.0 Mobile Safari/537.36"
                    }
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView, request: WebResourceRequest
                        ): Boolean {
                            val url = request.url.toString()
                            if (url.startsWith("streamx://")) { onSuccess(url); return true }
                            return false
                        }
                        override fun onPageStarted(view: WebView, url: String, f: Bitmap?) {
                            val secure = url.startsWith("https://")
                            val host   = runCatching {
                                Uri.parse(url).host?.removePrefix("www.") ?: url
                            }.getOrDefault(url)
                            onStateChange(this@apply, true, secure, host, view.canGoBack())
                        }
                        override fun onPageFinished(view: WebView, url: String) {
                            onStateChange(this@apply, false, url.startsWith("https://"), runCatching {
                                Uri.parse(url).host?.removePrefix("www.") ?: url
                            }.getOrDefault(url), view.canGoBack())
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView, p: Int) {
                            onProgress(p / 100f)
                        }
                        override fun onCreateWindow(
                            view: WebView, isDialog: Boolean,
                            isUserGesture: Boolean, msg: android.os.Message
                        ): Boolean {
                            val popup = WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(
                                        v: WebView, r: WebResourceRequest
                                    ): Boolean {
                                        val u = r.url.toString()
                                        if (u.startsWith("streamx://")) { onSuccess(u); return true }
                                        v.loadUrl(u); return true
                                    }
                                }
                            }
                            (msg.obj as? WebView.WebViewTransport)?.webView = popup
                            msg.sendToTarget()
                            return true
                        }
                    }
                    loadUrl(initialUrl)
                    onStateChange(this, true, initialUrl.startsWith("https://"), "", false)
                }
            }
        )

        // ── Loading overlay — AnimatedVisibility is safe here ────
        // No outer ColumnScope → resolves to top-level AnimatedVisibility ✅
        AnimatedVisibility(
            // ✅ FIX 5 — widened from `progress < .18f` to `.4f`.
            // Gumroad's checkout reports high progress while its own JS/CSS
            // is still rendering, so hiding the overlay too early exposed a
            // brief white/blank WebView frame underneath. Now the dark
            // overlay stays up until the page is meaningfully painted.
            visible  = isLoading && progress < .4f,
            enter    = fadeIn(),
            exit     = fadeOut(tween(500)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(C_BG),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(Modifier.size(80.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            modifier    = Modifier.size(80.dp).rotate(spinCw),
                            color       = C_CYAN.copy(pulse),
                            strokeWidth = 1.8.dp,
                            trackColor  = Color.Transparent
                        )
                        CircularProgressIndicator(
                            modifier    = Modifier.size(54.dp).rotate(spinCcw),
                            color       = C_PURPLE.copy(pulse),
                            strokeWidth = 1.8.dp,
                            trackColor  = Color.Transparent
                        )
                        Box(
                            Modifier
                                .size(12.dp)
                                .drawBehind {
                                    drawCircle(C_CYAN.copy(.4f), radius = size.minDimension * 2.5f)
                                }
                                .background(
                                    Brush.radialGradient(listOf(C_CYAN, C_PURPLE)),
                                    CircleShape
                                )
                        )
                    }
                    Spacer(Modifier.height(32.dp))
                    Text(
                        "LOADING SECURE CHECKOUT",
                        color         = C_CYAN.copy(.6f),
                        fontSize      = 11.sp,
                        fontWeight    = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        currentHost.ifEmpty { "gumroad.com" },
                        color    = Color.White.copy(.22f),
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  GlassButton — reusable frosted-glass icon button
// ═══════════════════════════════════════════════════════════════════
@Composable
private fun GlassButton(
    onClick : () -> Unit,
    enabled : Boolean = true,
    content : @Composable BoxScope.() -> Unit,
) {
    Box(
        Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (enabled) C_GLASS else Color.Transparent)
            .then(
                if (enabled)
                    Modifier
                        .border(1.dp, C_BORDER, RoundedCornerShape(10.dp))
                        .clickable { onClick() }
                else Modifier
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}
