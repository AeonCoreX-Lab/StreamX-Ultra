package com.aeoncorex.streamx.ui.premium

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Handles the Gumroad payment redirect deep link.
 *
 * Flow:
 *   1. User taps "Subscribe" → PremiumScreen builds Gumroad URL with
 *      success_url = streamx://payment/success?plan=monthly
 *   2. Gumroad processes payment → sends webhook to backend → Firestore updated
 *   3. Gumroad redirects browser to success_url
 *   4. Android opens this Activity via intent-filter
 *   5. Activity polls Firestore until isPremium = true, then auto-redirects to app
 *
 * AndroidManifest.xml entry (already added):
 *   <activity android:name=".ui.premium.PaymentSuccessActivity"
 *       android:exported="true" android:launchMode="singleTop">
 *     <intent-filter android:autoVerify="true">
 *       <action android:name="android.intent.action.VIEW"/>
 *       <category android:name="android.intent.category.DEFAULT"/>
 *       <category android:name="android.intent.category.BROWSABLE"/>
 *       <data android:scheme="streamx" android:host="payment" android:pathPrefix="/success"/>
 *     </intent-filter>
 *   </activity>
 */
class PaymentSuccessActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Read plan from deep link query param: streamx://payment/success?plan=yearly
        val plan = intent?.data?.getQueryParameter("plan") ?: "monthly"

        setContent {
            PaymentSuccessScreen(
                plan   = plan,
                onDone = {
                    startActivity(
                        Intent(
                            this,
                            Class.forName("com.aeoncorex.streamx.MainActivity")
                        ).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            putExtra("openPremium", true)
                        }
                    )
                    finish()
                }
            )
        }
    }
}

@Composable
private fun PaymentSuccessScreen(plan: String, onDone: () -> Unit) {
    val scope      = rememberCoroutineScope()
    var isPremium  by remember { mutableStateOf(false) }
    var isChecking by remember { mutableStateOf(true) }
    var pollCount  by remember { mutableIntStateOf(0) }

    // Poll Firestore until webhook fires and isPremium = true
    // Webhook usually fires within 2–5 seconds of Gumroad processing
    LaunchedEffect(Unit) {
        PremiumManager.invalidateCache()
        repeat(20) { attempt ->
            pollCount  = attempt + 1
            isPremium  = PremiumManager.isPremium()
            if (isPremium) { isChecking = false; return@LaunchedEffect }
            delay(3000)
        }
        // 60 seconds total — give up and show pending state
        isChecking = false
    }

    val Purple  = Color(0xFF7C4DFF)
    val Gold    = Color(0xFFFFD700)
    val DarkBg  = Color(0xFF0A0818)

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(DarkBg, Color(0xFF0D0D20)))),
        contentAlignment = Alignment.Center
    ) {
        val state = when {
            isChecking && !isPremium -> "checking"
            isPremium                -> "success"
            else                     -> "pending"
        }

        AnimatedContent(targetState = state, label = "payment_state") { s ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier            = Modifier.padding(40.dp)
            ) {
                when (s) {

                    "checking" -> {
                        CircularProgressIndicator(
                            color    = Purple,
                            modifier = Modifier.size(56.dp),
                            strokeWidth = 4.dp,
                        )
                        Spacer(Modifier.height(28.dp))
                        Text("Confirming payment…",
                            color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("This usually takes a few seconds. ($pollCount/20)",
                            color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }

                    "success" -> {
                        // Auto-redirect after 2 seconds
                        LaunchedEffect(Unit) { delay(2000); onDone() }

                        Box(
                            Modifier.size(100.dp).background(
                                Brush.radialGradient(listOf(Purple.copy(0.3f), Color.Transparent)),
                                CircleShape
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.CheckCircle, null,
                                tint     = Color(0xFF69F0AE),
                                modifier = Modifier.size(72.dp))
                        }
                        Spacer(Modifier.height(24.dp))
                        Text("Payment Successful! 🎉",
                            color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Welcome to StreamX Premium!\nYour ${if (plan == "yearly") "yearly" else "monthly"} subscription is now active.",
                            color = Color.LightGray, fontSize = 15.sp,
                            textAlign = TextAlign.Center, lineHeight = 24.sp
                        )
                        Spacer(Modifier.height(32.dp))
                        LinearProgressIndicator(
                            modifier   = Modifier.fillMaxWidth(0.6f).height(3.dp),
                            color      = Purple,
                            trackColor = Color.White.copy(0.1f),
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Redirecting to app…", color = Color.Gray, fontSize = 11.sp)
                    }

                    "pending" -> {
                        // Webhook hasn't fired yet — tell user it'll happen soon
                        Icon(Icons.Rounded.WorkspacePremium, null,
                            tint = Gold, modifier = Modifier.size(72.dp))
                        Spacer(Modifier.height(24.dp))
                        Text("Almost there!",
                            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Your payment was received.\nPremium will activate within 1 minute.\n\nYou can safely return to the app.",
                            color = Color.LightGray, fontSize = 14.sp,
                            textAlign = TextAlign.Center, lineHeight = 22.sp
                        )
                        Spacer(Modifier.height(28.dp))
                        Button(
                            onClick  = {
                                scope.launch {
                                    PremiumManager.invalidateCache()
                                    onDone()
                                }
                            },
                            colors   = ButtonDefaults.buttonColors(containerColor = Purple),
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape    = RoundedCornerShape(14.dp),
                        ) {
                            Text("Go to App", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
