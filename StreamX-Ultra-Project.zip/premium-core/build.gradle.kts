plugins {
    id("com.android.library")
    // AGP 9.0+ has built-in Kotlin — kotlin.android must NOT be applied here.
    // compileOptions + kotlin { compilerOptions } below are still required
    // to set JVM target and fix Compose classpath resolution.
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.aeoncorex.streamx.ui.premium"
    compileSdk = 36

    defaultConfig {
        minSdk = 28
    }

    // No custom sourceSets needed — standard Android layout:
    // src/main/java/  +  src/main/AndroidManifest.xml
    // (srcDirs/setSrcDirs APIs removed in Gradle 9.4.1)

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
            freeCompilerArgs.addAll(
                "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api"
            )
        }
    }
}

dependencies {
    // Firebase BOM — KTX modules merged into main since BOM 32+
    implementation(platform("com.google.firebase:firebase-bom:34.11.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")

    // Compose — version synced with main app
    implementation(platform("androidx.compose:compose-bom:2026.03.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.0")

    // Activity Compose — required for setContent in Activity
    implementation("androidx.activity:activity-compose:1.13.0")

    // Navigation — NavController, BackHandler
    implementation("androidx.navigation:navigation-compose:2.8.8")

    // Image loading
    implementation("io.coil-kt:coil-compose:2.7.0")
}
