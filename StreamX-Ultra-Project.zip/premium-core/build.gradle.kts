plugins {
    id("com.android.library")
    // org.jetbrains.kotlin.android removed — Kotlin is built-in since AGP 9.0
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.aeoncorex.streamx.ui.premium"
    compileSdk = 36

    defaultConfig {
        minSdk = 28
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Firebase BOM — KTX modules merged into main since BOM 32+, use base artifacts
    implementation(platform("com.google.firebase:firebase-bom:34.11.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")

    // UI & Compose — version synced with main app
    implementation(platform("androidx.compose:compose-bom:2026.03.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    
    // Image loading
    implementation("io.coil-kt:coil-compose:2.7.0")
}