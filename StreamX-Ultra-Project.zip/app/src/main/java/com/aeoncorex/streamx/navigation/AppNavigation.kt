package com.aeoncorex.streamx.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aeoncorex.streamx.ui.account.AccountScreen
import com.aeoncorex.streamx.ui.addons.AddonScreen
import com.aeoncorex.streamx.ui.auth.AuthScreen
import com.aeoncorex.streamx.ui.main.MainScreen
import com.aeoncorex.streamx.ui.settings.SettingsScreen
import com.aeoncorex.streamx.ui.splash.SplashScreen
import com.aeoncorex.streamx.ui.onboarding.OnboardingScreen
import com.aeoncorex.streamx.ui.theme.ThemeScreen
import com.aeoncorex.streamx.ui.theme.ThemeViewModel
import com.aeoncorex.streamx.ui.privacy.PrivacyPolicyScreen
import com.aeoncorex.streamx.ui.about.AboutScreen
import com.aeoncorex.streamx.ui.music.MusicScreen
import com.aeoncorex.streamx.ui.music.MusicPlayerScreen
import com.aeoncorex.streamx.ui.player.PlayerScreen
import com.aeoncorex.streamx.ui.player.EventPlayerScreen
import com.aeoncorex.streamx.ui.copyright.CopyrightScreen
import com.aeoncorex.streamx.ui.premium.PremiumScreen
import com.aeoncorex.streamx.ui.movie.MovieScreen
import com.aeoncorex.streamx.ui.movie.MovieDetailsScreen
import com.aeoncorex.streamx.ui.movie.MovieSettingsScreen
import com.aeoncorex.streamx.ui.movie.TrackerLoginScreen
import com.aeoncorex.streamx.ui.movie.MovieLinkSelectionScreen
import com.aeoncorex.streamx.ui.movie.MoviePlayerScreen
import com.aeoncorex.streamx.ui.movie.ExoMoviePlayerScreen
import com.aeoncorex.streamx.ui.movie.ExoSourceSelectionScreen
import com.aeoncorex.streamx.ui.notifications.NotificationsScreen
import com.aeoncorex.streamx.ui.movie.PersonDetailScreen
import java.net.URLEncoder

// NOTE: WAF-challenge UI is embedded directly inside ExoSourceSelectionScreen
// (see WafChallengeSection there) — that's the only screen that triggers
// WorkerStreamProviderEngine's provider fan-out and the only place a WAF
// prompt is contextually meaningful (the user can see exactly which
// title/source it's unlocking). There is no global overlay mounted here.
@Composable
fun AppNavigation(
    themeViewModel:    ThemeViewModel,
    pendingInstallUrl: String? = null   // from deeplink: streamx://install-addon?url=...
) {
    val navController = rememberNavController()

    LaunchedEffect(pendingInstallUrl) {
        if (!pendingInstallUrl.isNullOrEmpty()) {
            val enc = URLEncoder.encode(pendingInstallUrl, "UTF-8")
            navController.navigate("addons?installUrl=$enc") {
                launchSingleTop = true
            }
        }
    }

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash")      { SplashScreen(navController) }
        composable("onboarding")  { OnboardingScreen(navController) }
        composable("auth")        { AuthScreen(navController) }
        composable("home")        { MainScreen(navController) }

        // ── Addon Management ──────────────────────────────────────────────────
        composable(
            route = "addons?installUrl={installUrl}",
            arguments = listOf(
                navArgument("installUrl") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStack ->
            val installUrl = backStack.arguments?.getString("installUrl")
                ?.let { java.net.URLDecoder.decode(it, "UTF-8") }
            AddonScreen(navController = navController, autoInstallUrl = installUrl)
        }
        composable("addons") { AddonScreen(navController) }

        // ── Live TV ───────────────────────────────────────────────────────────
        composable(
            route     = "player/{encodedUrl}",
            arguments = listOf(navArgument("encodedUrl") { type = NavType.StringType })
        ) { back ->
            PlayerScreen(navController = navController,
                encodedUrl = back.arguments?.getString("encodedUrl") ?: "")
        }

        composable(
            route = "event_player/{eventId}/{streamIndex}/{encodedTitle}",
            arguments = listOf(
                navArgument("eventId")      { type = NavType.StringType },
                navArgument("streamIndex")  { type = NavType.IntType; defaultValue = 0 },
                navArgument("encodedTitle") { type = NavType.StringType; defaultValue = "" }
            )
        ) { back ->
            EventPlayerScreen(navController = navController,
                eventId      = back.arguments?.getString("eventId")      ?: "",
                streamIndex  = back.arguments?.getInt("streamIndex")     ?: 0,
                encodedTitle = back.arguments?.getString("encodedTitle") ?: "")
        }

        // ── Movie ─────────────────────────────────────────────────────────────
        composable("movie")          { MovieScreen(navController) }
        composable("movie_settings") { MovieSettingsScreen(navController) }

        composable(
            route     = "tracker_login/{siteId}/{displayName}/{baseUrl}?instructions={instructions}&loginCheckPath={loginCheckPath}&loginCheckSelector={loginCheckSelector}",
            arguments = listOf(
                navArgument("siteId")             { type = NavType.StringType },
                navArgument("displayName")        { type = NavType.StringType },
                navArgument("baseUrl")            { type = NavType.StringType },
                navArgument("instructions")       { type = NavType.StringType; defaultValue = "" },
                navArgument("loginCheckPath")     { type = NavType.StringType; defaultValue = "" },
                navArgument("loginCheckSelector") { type = NavType.StringType; defaultValue = "" }
            )
        ) { back ->
            fun arg(name: String) = back.arguments?.getString(name)?.let {
                try { java.net.URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it }
            } ?: ""
            TrackerLoginScreen(
                navController      = navController,
                siteId             = arg("siteId"),
                displayName        = arg("displayName"),
                baseUrl            = arg("baseUrl"),
                instructions       = arg("instructions"),
                loginCheckPath     = arg("loginCheckPath").takeIf { it.isNotEmpty() },
                loginCheckSelector = arg("loginCheckSelector").takeIf { it.isNotEmpty() }
            )
        }

        composable(
            route     = "movie_detail/{movieId}/{type}",
            arguments = listOf(
                navArgument("movieId") { type = NavType.IntType },
                navArgument("type")    { type = NavType.StringType }
            )
        ) { back ->
            MovieDetailsScreen(navController = navController,
                movieId   = back.arguments?.getInt("movieId") ?: 0,
                movieType = back.arguments?.getString("type") ?: "MOVIE")
        }

        composable(
            route     = "exo_source/{imdbId}/{tmdbId}/{title}/{type}/{season}/{episode}",
            arguments = listOf(
                navArgument("imdbId")  { type = NavType.StringType },
                navArgument("tmdbId")  { type = NavType.IntType },
                navArgument("title")   { type = NavType.StringType },
                navArgument("type")    { type = NavType.StringType },
                navArgument("season")  { type = NavType.IntType },
                navArgument("episode") { type = NavType.IntType }
            )
        ) { back ->
            ExoSourceSelectionScreen(navController = navController,
                imdbId  = back.arguments?.getString("imdbId")  ?: "",
                tmdbId  = back.arguments?.getInt("tmdbId")     ?: 0,
                title   = back.arguments?.getString("title")   ?: "",
                type    = back.arguments?.getString("type")    ?: "MOVIE",
                season  = back.arguments?.getInt("season")     ?: 0,
                episode = back.arguments?.getInt("episode")    ?: 0)
        }

        composable(
            route     = "exo_player/{encodedUrl}/{title}/{quality}/{language}/{imdbId}/{type}/{season}/{episode}/{subtitlesJson}/{headersJson}",
            arguments = listOf(
                navArgument("encodedUrl")    { type = NavType.StringType },
                navArgument("title")         { type = NavType.StringType },
                navArgument("quality")       { type = NavType.StringType },
                navArgument("language")      { type = NavType.StringType },
                navArgument("imdbId")        { type = NavType.StringType },
                navArgument("type")          { type = NavType.StringType },
                navArgument("season")        { type = NavType.IntType },
                navArgument("episode")       { type = NavType.IntType },
                navArgument("subtitlesJson") { type = NavType.StringType; defaultValue = "%5B%5D" },
                navArgument("headersJson")   { type = NavType.StringType; defaultValue = "%7B%7D" }
            )
        ) { back ->
            ExoMoviePlayerScreen(navController = navController,
                streamUrl     = back.arguments?.getString("encodedUrl")    ?: "",
                title         = back.arguments?.getString("title")         ?: "",
                quality       = back.arguments?.getString("quality")       ?: "Auto",
                language      = back.arguments?.getString("language")      ?: "English",
                imdbId        = back.arguments?.getString("imdbId"),
                movieType     = back.arguments?.getString("type")          ?: "MOVIE",
                season        = back.arguments?.getInt("season")           ?: 0,
                subtitlesJson = back.arguments?.getString("subtitlesJson") ?: "[]",
                headersJson   = back.arguments?.getString("headersJson")   ?: "{}",
                episode       = back.arguments?.getInt("episode")          ?: 0)
        }

        // ── Torrent ───────────────────────────────────────────────────────────
        composable(
            route     = "torrent_selection/{imdbId}/{tmdbId}/{title}/{type}/{season}/{episode}",
            arguments = listOf(
                navArgument("imdbId")  { type = NavType.StringType },
                navArgument("tmdbId")  { type = NavType.IntType },
                navArgument("title")   { type = NavType.StringType },
                navArgument("type")    { type = NavType.StringType },
                navArgument("season")  { type = NavType.IntType },
                navArgument("episode") { type = NavType.IntType }
            )
        ) { back ->
            MovieLinkSelectionScreen(navController = navController,
                imdbId  = back.arguments?.getString("imdbId")  ?: "",
                tmdbId  = back.arguments?.getInt("tmdbId")     ?: 0,
                title   = back.arguments?.getString("title")   ?: "",
                type    = back.arguments?.getString("type")    ?: "MOVIE",
                season  = back.arguments?.getInt("season")     ?: 0,
                episode = back.arguments?.getInt("episode")    ?: 0)
        }

        composable(
            route     = "torrent_player/{encodedUrl}?imdbId={imdbId}&trackerSiteId={trackerSiteId}",
            arguments = listOf(
                navArgument("encodedUrl")    { type = NavType.StringType },
                navArgument("imdbId")        { type = NavType.StringType; defaultValue = "" },
                // Set only when encodedUrl is a private tracker's
                // authenticated .torrent download link (see
                // MovieLinkSelectionScreen's playTorrent()) — empty for
                // a normal magnet link. MoviePlayerScreen uses this to
                // look up the live cookie from PrivateTrackerCookieStore
                // at play time; the cookie itself never travels through
                // this route.
                navArgument("trackerSiteId") { type = NavType.StringType; defaultValue = "" }
            )
        ) { back ->
            MoviePlayerScreen(navController = navController,
                encodedUrl    = back.arguments?.getString("encodedUrl") ?: "",
                imdbId        = back.arguments?.getString("imdbId") ?: "",
                trackerSiteId = back.arguments?.getString("trackerSiteId") ?: "")
        }

        // ── Music ─────────────────────────────────────────────────────────────
        composable("music")        { MusicScreen(navController) }
        composable("music_player") { MusicPlayerScreen(navController) }

        // ── Other ─────────────────────────────────────────────────────────────
        composable("settings")      { SettingsScreen(navController) }
        composable("account")       { AccountScreen(navController) }
        composable("theme")         { ThemeScreen(navController, themeViewModel) }
        composable("privacy")       { PrivacyPolicyScreen(navController) }
        composable("about")         { AboutScreen(navController) }
        composable("copyright")     { CopyrightScreen(navController) }
        composable("premium")       { PremiumScreen(navController) }
        composable("notifications") { NotificationsScreen() }
        composable("person_detail/{personId}") { back ->
            PersonDetailScreen(
                personId      = back.arguments?.getString("personId")?.toIntOrNull() ?: return@composable,
                navController = navController)
        }
    }
}