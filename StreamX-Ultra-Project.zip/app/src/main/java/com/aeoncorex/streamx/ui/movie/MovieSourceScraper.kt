package com.aeoncorex.streamx.ui.movie

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

// ═══════════════════════════════════════════════════════════════════
//  MovieSourceScraper — Production In-App Fallback Scraper
//  ──────────────────────────────────────────────────────────
//  Runs when backend is unreachable. Mirrors backend logic in Kotlin:
//    1. Fetch embed page HTML
//    2. Follow iframe chain up to 4 levels deep
//    3. Decode obfuscated JS (atob/Base64, hex, packed)
//    4. Extract .m3u8 / .mpd / .mp4 URLs from all patterns
//    5. Parallel source scraping for speed
//
//  Sources (tested working 2025-2026):
//    English:  vidsrc.me, vidsrc.to, vidlink.pro, moviesapi.club,
//              embed.su, autoembed.cc, smashystream.com, 2embed.stream
//    Hindi/Dub: fzmovies.net, downloads-anymovies.co
// ═══════════════════════════════════════════════════════════════════
object MovieSourceScraper {

    private const val TAG = "MovieSourceScraper"
    private const val MAX_IFRAME_DEPTH = 4

    private val client = OkHttpClient.Builder()
        .connectTimeout(14, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder()
                    .header("User-Agent",      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                    .header("Accept",          "text/html,application/xhtml+xml,*/*;q=0.9")
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Sec-Fetch-Dest",  "iframe")
                    .header("Sec-Fetch-Mode",  "navigate")
                    .build()
            )
        }
        .build()

    // ── Result types ──────────────────────────────────────────────
    data class StreamSource(
        val url:        String,
        val type:       StreamType,
        val quality:    String  = "Auto",
        val language:   String  = "English",
        val sourceSite: String  = "",
        val label:      String  = ""
    )

    enum class StreamType { HLS, MP4, DASH }

    // ── Main entry point (parallel scraping) ──────────────────────
    suspend fun getSources(
        tmdbId:   Int?,
        imdbId:   String?,
        title:    String,
        type:     MovieType,
        season:   Int    = 0,
        episode:  Int    = 0,
        language: String = "English"
    ): List<StreamSource> = withContext(Dispatchers.IO) {

        val isSeries  = type == MovieType.SERIES
        val isEnglish = language == "English" || language == "Original"
        val results   = mutableListOf<StreamSource>()

        Log.d(TAG, "Scraping: title=$title lang=$language type=$type")

        coroutineScope {
            val jobs = buildSources(tmdbId, imdbId, title, type, season, episode, language)
                .map { src ->
                    async {
                        try {
                            val streams = extractFromSource(src, title, isSeries, season, episode, language)
                            Log.d(TAG, "${src.site}: ${streams.size} streams")
                            streams
                        } catch (e: Exception) {
                            Log.w(TAG, "${src.site}: ${e.message}")
                            emptyList()
                        }
                    }
                }

            // Collect results as they come in, stop when we have 4 good streams
            for (job in jobs) {
                val streams = job.await()
                for (s in streams) {
                    if (!results.any { it.url == s.url }) results.add(s)
                }
                if (results.size >= 4) break
            }
        }

        val sorted = results.sortedWith(
            compareByDescending<StreamSource> { it.type == StreamType.HLS }
                .thenByDescending { qualityScore(it.quality) }
        )

        Log.d(TAG, "Total unique streams: ${sorted.size}")
        sorted
    }

    // ── Source list ───────────────────────────────────────────────
    private data class ScrapeSource(
        val site:    String,
        val url:     String,
        val referer: String,
        val dubbed:  Boolean = false,
        val dubLang: String  = "",
    )

    private fun buildSources(
        tmdbId: Int?, imdbId: String?, title: String,
        type: MovieType, season: Int, episode: Int, language: String
    ): List<ScrapeSource> {
        val s         = mutableListOf<ScrapeSource>()
        val id        = (tmdbId?.toString() ?: imdbId ?: "")
        val isSeries  = type == MovieType.SERIES
        val isEnglish = language == "English" || language == "Original"

        if (isEnglish) {
            // 1. vidsrc.me
            if (id.isNotEmpty()) s.add(ScrapeSource("vidsrc.me",
                if (isSeries) "https://vidsrc.me/embed/tv?tmdb=${tmdbId?:""}&season=$season&episode=$episode"
                else          "https://vidsrc.me/embed/movie?tmdb=${tmdbId?:""}&imdb=${imdbId?:""}",
                "https://vidsrc.me/"))

            // 2. vidsrc.to
            if (id.isNotEmpty()) s.add(ScrapeSource("vidsrc.to",
                if (isSeries) "https://vidsrc.to/embed/tv/$id/$season/$episode"
                else          "https://vidsrc.to/embed/movie/$id",
                "https://vidsrc.to/"))

            // 3. vidlink.pro
            if (tmdbId != null) s.add(ScrapeSource("vidlink.pro",
                if (isSeries) "https://vidlink.pro/tv/$tmdbId/$season/$episode?autoplay=true"
                else          "https://vidlink.pro/movie/$tmdbId?autoplay=true",
                "https://vidlink.pro/"))

            // 4. moviesapi.club
            if (tmdbId != null) s.add(ScrapeSource("moviesapi.club",
                if (isSeries) "https://moviesapi.club/tv/$tmdbId-$season-$episode"
                else          "https://moviesapi.club/movie/$tmdbId",
                "https://moviesapi.club/"))

            // 5. embed.su
            if (tmdbId != null) s.add(ScrapeSource("embed.su",
                if (isSeries) "https://embed.su/embed/tv/$tmdbId/$season/$episode"
                else          "https://embed.su/embed/movie/$tmdbId",
                "https://embed.su/"))

            // 6. autoembed.cc
            if (tmdbId != null) s.add(ScrapeSource("autoembed.cc",
                if (isSeries) "https://autoembed.cc/tv/tmdb/$tmdbId-$season-$episode"
                else          "https://autoembed.cc/movie/tmdb/$tmdbId",
                "https://autoembed.cc/"))

            // 7. smashystream
            if (tmdbId != null) s.add(ScrapeSource("smashystream.com",
                if (isSeries) "https://player.smashystream.com/tv/$tmdbId/$season/$episode"
                else          "https://player.smashystream.com/movie/$tmdbId",
                "https://smashystream.com/"))

            // 8. vidsrc.xyz
            s.add(ScrapeSource("vidsrc.xyz",
                if (isSeries) "https://vidsrc.xyz/embed/tv?tmdb=${tmdbId?:""}&season=$season&episode=$episode"
                else          "https://vidsrc.xyz/embed/movie?tmdb=${tmdbId?:""}&imdb=${imdbId?:""}",
                "https://vidsrc.xyz/"))

            // 9. 2embed
            s.add(ScrapeSource("2embed.stream",
                if (isSeries) "https://www.2embed.stream/embed/tv/${tmdbId?:imdbId}/$season/$episode"
                else          "https://www.2embed.stream/embed/movie/${tmdbId?:imdbId}",
                "https://www.2embed.stream/"))

        } else {
            // Hindi / Tamil / Telugu dubbed
            val enc = java.net.URLEncoder.encode(title, "UTF-8")
            s.add(ScrapeSource("fzmovie.net",
                "https://fzmovies.net/search.php?searchname=$enc+${language.lowercase()}+dubbed&searchby=moviename&category=All&beginsearch=Search",
                "https://fzmovies.net/", dubbed = true, dubLang = language.lowercase()))

            s.add(ScrapeSource("downloads-anymovies.co",
                "https://downloads-anymovies.co/?s=$enc+${language.lowercase()}+dubbed",
                "https://downloads-anymovies.co/", dubbed = true, dubLang = language.lowercase()))

            // English fallback for dubbed viewers
            if (tmdbId != null) {
                s.add(ScrapeSource("vidsrc.me",
                    if (isSeries) "https://vidsrc.me/embed/tv?tmdb=$tmdbId&season=$season&episode=$episode"
                    else          "https://vidsrc.me/embed/movie?tmdb=$tmdbId",
                    "https://vidsrc.me/"))
            }
        }
        return s
    }

    // ── Extract streams from one source ───────────────────────────
    private fun extractFromSource(
        src: ScrapeSource, title: String,
        isSeries: Boolean, season: Int, episode: Int, language: String
    ): List<StreamSource> {

        if (src.site == "fzmovie.net" && src.dubbed) return extractFzmovies(src)
        if (src.site == "downloads-anymovies.co")    return extractAnymovies(src)

        val html = fetchHtml(src.url, src.referer) ?: return emptyList()
        var streams = parseAllStreams(html, src.site)
        if (streams.isNotEmpty()) return streams

        // Follow iframe chain up to MAX_IFRAME_DEPTH levels
        var currentUrl = src.url
        var currentRef = src.referer
        var currentHtml = html

        for (depth in 0 until MAX_IFRAME_DEPTH) {
            val iframeSrc = findIframe(currentHtml, currentRef) ?: break
            if (iframeSrc == currentUrl) break
            currentRef  = currentUrl
            currentUrl  = iframeSrc
            currentHtml = fetchHtml(currentUrl, currentRef) ?: break
            streams     = parseAllStreams(currentHtml, src.site)
            if (streams.isNotEmpty()) return streams
        }

        return emptyList()
    }

    // ── Parse all stream URLs with JS decoding ────────────────────
    private fun parseAllStreams(html: String, site: String): List<StreamSource> {
        val found = mutableListOf<StreamSource>()
        val seen  = mutableSetOf<String>()

        // Build list of HTML layers (decoded versions)
        val layers = buildDecodedLayers(html)

        fun add(url: String, type: StreamType, quality: String) {
            if (!seen.contains(url) && isValidStreamUrl(url)) {
                seen.add(url)
                found.add(StreamSource(url, type, quality, "English", site, "$quality ($site)"))
            }
        }

        for (layer in layers) {
            // .m3u8 HLS
            Pattern.compile("""["'`](https?://[^"'`\s]{15,}\.m3u8[^"'`\s]{0,200})["'`]""")
                .matcher(layer).run { while (find()) group(1)?.let { add(it, StreamType.HLS, detectQuality(it)) } }

            // .mpd DASH
            Pattern.compile("""["'`](https?://[^"'`\s]{15,}\.mpd[^"'`\s]{0,200})["'`]""")
                .matcher(layer).run { while (find()) group(1)?.let { add(it, StreamType.DASH, detectQuality(it)) } }

            // JWPlayer sources array: file:"...", label:"1080p"
            Pattern.compile("""sources\s*:\s*\[([^\]]{10,3000})\]""")
                .matcher(layer).run {
                    while (find()) {
                        val block   = group(1) ?: continue
                        val filePat = Pattern.compile("""file\s*:\s*["'`](https?://[^"'`\s]+)["'`]""")
                        val qualPat = Pattern.compile("""label\s*:\s*["'`]([^"'`]+)["'`]""")
                        val files   = mutableListOf<String>()
                        val quals   = mutableListOf<String>()
                        filePat.matcher(block).run { while (find()) files.add(group(1) ?: "") }
                        qualPat.matcher(block).run { while (find()) quals.add(group(1) ?: "") }
                        files.forEachIndexed { i, f ->
                            val t = when { f.contains(".m3u8") -> StreamType.HLS; f.contains(".mpd") -> StreamType.DASH; else -> StreamType.MP4 }
                            add(f, t, quals.getOrNull(i) ?: detectQuality(f))
                        }
                    }
                }

            // VideoJS / generic file:"..."
            Pattern.compile("""file\s*:\s*["'`](https?://[^"'`\s]{15,})["'`]""")
                .matcher(layer).run {
                    while (find()) group(1)?.let { u ->
                        val t = when { u.contains(".m3u8") -> StreamType.HLS; u.contains(".mpd") -> StreamType.DASH; else -> StreamType.MP4 }
                        add(u, t, detectQuality(u))
                    }
                }

            // <source src="...">
            Pattern.compile("""<source[^>]+src=["'](https?://[^"'\s]{15,})["'][^>]*>""")
                .matcher(layer).run {
                    while (find()) group(1)?.let { u ->
                        val t = when { u.contains(".m3u8") -> StreamType.HLS; u.contains(".mpd") -> StreamType.DASH; else -> StreamType.MP4 }
                        add(u, t, detectQuality(u))
                    }
                }

            // Direct .mp4
            Pattern.compile("""["'`](https?://[^"'`\s]{15,}\.mp4[^"'`\s]{0,200})["'`]""")
                .matcher(layer).run { while (find()) group(1)?.let { add(it, StreamType.MP4, detectQuality(it)) } }

            // JSON "src":"..."
            Pattern.compile(""""src"\s*:\s*"(https?://[^"]{15,})"""")
                .matcher(layer).run {
                    while (find()) group(1)?.let { u ->
                        val t = when { u.contains(".m3u8") -> StreamType.HLS; u.contains(".mpd") -> StreamType.DASH; else -> StreamType.MP4 }
                        add(u, t, detectQuality(u))
                    }
                }
        }

        return found.sortedWith(
            compareByDescending<StreamSource> { it.type == StreamType.HLS }
                .thenByDescending { it.type == StreamType.DASH }
                .thenByDescending { qualityScore(it.quality) }
        )
    }

    // ── Build decoded JS layers ───────────────────────────────────
    private fun buildDecodedLayers(html: String): List<String> {
        val layers = mutableListOf(html)

        // atob() Base64 strings
        Pattern.compile("""atob\(["'`]([A-Za-z0-9+/=]{20,})["'`]\)""")
            .matcher(html).run {
                while (find()) {
                    try { layers.add(String(Base64.decode(group(1), Base64.DEFAULT))) } catch (_: Exception) {}
                }
            }

        // Standalone base64 strings that look like HTML/JS
        Pattern.compile("""["'`]([A-Za-z0-9+/]{80,}={0,2})["'`]""")
            .matcher(html).run {
                while (find()) {
                    try {
                        val decoded = String(Base64.decode(group(1), Base64.DEFAULT))
                        if (decoded.contains("http") || decoded.contains(".m3u8")) layers.add(decoded)
                    } catch (_: Exception) {}
                }
            }

        // Hex encoded: \x68\x74\x74\x70
        Pattern.compile("""((?:\\x[0-9a-fA-F]{2}){10,})""")
            .matcher(html).run {
                while (find()) {
                    try {
                        val decoded = group(1).replace(Regex("""\\x([0-9a-fA-F]{2})""")) {
                            it.groupValues[1].toInt(16).toChar().toString()
                        }
                        if (decoded.contains("http")) layers.add(decoded)
                    } catch (_: Exception) {}
                }
            }

        return layers
    }

    // ── fzmovies.net extractor ────────────────────────────────────
    private fun extractFzmovies(src: ScrapeSource): List<StreamSource> {
        val searchHtml = fetchHtml(src.url, src.referer) ?: return emptyList()
        val linkMatch  = Pattern.compile("""href="(/movie-[^"]+?\.htm)"""").matcher(searchHtml)
        if (!linkMatch.find()) return emptyList()

        val movieUrl  = "https://fzmovies.net${linkMatch.group(1)}"
        val movieHtml = fetchHtml(movieUrl, src.referer) ?: return emptyList()

        var streams = parseAllStreams(movieHtml, src.site)
        if (streams.isNotEmpty()) return streams.map { it.copy(language = src.dubLang) }

        val dlMatch = Pattern.compile("""href="(/[^"]*?(?:download|dl)[^"]*?)"""", Pattern.CASE_INSENSITIVE)
            .matcher(movieHtml)
        if (!dlMatch.find()) return emptyList()

        val dlHtml = fetchHtml("https://fzmovies.net${dlMatch.group(1)}", movieUrl) ?: return emptyList()
        streams = parseAllStreams(dlHtml, src.site)
        if (streams.isNotEmpty()) return streams.map { it.copy(language = src.dubLang) }

        // Direct MP4 fallback
        val mp4Match = Pattern.compile("""href="(https?://[^"]+?\.mp4[^"]*)"""", Pattern.CASE_INSENSITIVE)
            .matcher(dlHtml)
        if (mp4Match.find()) {
            val url = mp4Match.group(1) ?: return emptyList()
            return listOf(StreamSource(url, StreamType.MP4, detectQuality(url), src.dubLang, src.site))
        }
        return emptyList()
    }

    // ── downloads-anymovies.co extractor ─────────────────────────
    private fun extractAnymovies(src: ScrapeSource): List<StreamSource> {
        val searchHtml = fetchHtml(src.url, src.referer) ?: return emptyList()
        val linkMatch  = Pattern.compile("""href="(https?://downloads-anymovies\.co/[^"]+?)"""")
            .matcher(searchHtml)
        if (!linkMatch.find()) return emptyList()

        val movieHtml = fetchHtml(linkMatch.group(1) ?: "", src.referer) ?: return emptyList()
        var streams = parseAllStreams(movieHtml, src.site)
        if (streams.isNotEmpty()) return streams.map { it.copy(language = src.dubLang) }

        val dlMatch = Pattern.compile("""href="(https?://[^"]+?\.(?:mp4|m3u8)[^"]*)"""", Pattern.CASE_INSENSITIVE)
            .matcher(movieHtml)
        if (dlMatch.find()) {
            val url = dlMatch.group(1) ?: return emptyList()
            val t   = if (url.contains(".m3u8")) StreamType.HLS else StreamType.MP4
            return listOf(StreamSource(url, t, detectQuality(url), src.dubLang, src.site))
        }
        return emptyList()
    }

    // ── Find iframe src with smart resolution ─────────────────────
    private fun findIframe(html: String, base: String): String? {
        val pat = Pattern.compile("""<iframe[^>]+(?:src|data-src)\s*=\s*["']([^"']{10,})["'][^>]*>""", Pattern.CASE_INSENSITIVE)
        val m   = pat.matcher(html)
        while (m.find()) {
            val src = m.group(1) ?: continue
            if (src.startsWith("data:") || src.contains("google") || src.contains("facebook")) continue
            return when {
                src.startsWith("http")  -> src
                src.startsWith("//")    -> "https:$src"
                src.startsWith("/")     -> try { java.net.URL(base).let { "${it.protocol}://${it.host}$src" } } catch (_: Exception) { null }
                else                    -> try { java.net.URL(java.net.URL(base), src).toString() } catch (_: Exception) { null }
            } ?: continue
        }
        return null
    }

    // ── HTTP helper ───────────────────────────────────────────────
    fun fetchHtml(url: String, referer: String = ""): String? = try {
        val req = Request.Builder().url(url)
            .apply { if (referer.isNotEmpty()) header("Referer", referer) }
            .header("Sec-Fetch-Dest", "iframe")
            .build()
        val resp = client.newCall(req).execute()
        if (resp.isSuccessful) resp.body?.string() else null
    } catch (e: Exception) { Log.w(TAG, "fetchHtml $url: ${e.message}"); null }

    // ── Validators & Helpers ──────────────────────────────────────
    private fun isValidStreamUrl(url: String): Boolean {
        if (url.length < 15 || url.length > 500) return false
        val blocked = listOf("analytics", "pixel", "tracking", "ad.", "advert", ".jpg",
                             ".png", ".gif", ".css", "favicon", "doubleclick")
        return blocked.none { url.contains(it, ignoreCase = true) }
    }

    fun detectQuality(url: String): String = when {
        Regex("2160|4[kK]", RegexOption.IGNORE_CASE).containsMatchIn(url) -> "4K"
        url.contains("1080", true) -> "1080P"
        url.contains("720",  true) -> "720P"
        url.contains("480",  true) -> "480P"
        url.contains("360",  true) -> "360P"
        else                       -> "Auto"
    }

    private fun qualityScore(q: String) = when(q) {
        "4K" -> 4; "1080P" -> 3; "720P" -> 2; "480P" -> 1; else -> 0
    }
}
