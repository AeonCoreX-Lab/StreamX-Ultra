package com.aeoncorex.streamx.ui.movie

import android.util.Log
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile

// ═══════════════════════════════════════════════════════════════════
//  TorrentStreamServer — Local HTTP server for MPV/ExoPlayer
//  ──────────────────────────────────────────────────────────────────
//  MPV কে file path দেওয়ার বদলে http://127.0.0.1:PORT/stream দেওয়া হয়।
//  MPV তখন Range requests করে → seek করলে শুধু সেই position এর
//  bytes চায়, পুরো file download লাগে না → buffering কমে যায়।
//
//  Usage:
//    val url = TorrentStreamServer.start(File("/path/to/video.mkv"))
//    // url == "http://127.0.0.1:8088/stream"
//    mpv.playUrl(url)
//
//    TorrentStreamServer.stop()   // player শেষ হলে
// ═══════════════════════════════════════════════════════════════════

class TorrentStreamServer(
    private val videoFile: File,
    port: Int = 8088
) : NanoHTTPD(port) {

    companion object {
        private const val TAG  = "TorrentStreamServer"
        private const val PORT = 8088

        @Volatile private var instance: TorrentStreamServer? = null

        /**
         * Start (or restart) the HTTP server for [file].
         * Returns the full URL MPV should open.
         */
        fun start(file: File): String {
            // Stop previous instance if running
            instance?.stop()

            val server = TorrentStreamServer(file, PORT)
            try {
                server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                instance = server
                Log.d(TAG, "HTTP stream server started → port $PORT for: ${file.name}")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start HTTP server: ${e.message}")
            }
            return "http://127.0.0.1:$PORT/stream"
        }

        fun stop() {
            instance?.stop()
            instance = null
            Log.d(TAG, "HTTP stream server stopped")
        }

        /** Update the file being served (useful when path becomes known mid-download) */
        fun updateFile(file: File) {
            instance?.currentFile = file
            Log.d(TAG, "Updated stream file: ${file.name}")
        }
    }

    @Volatile var currentFile: File = videoFile

    override fun serve(session: IHTTPSession): Response {
        val file = currentFile
        if (!file.exists() || file.length() == 0L) {
            Log.w(TAG, "Serve called but file not ready: ${file.absolutePath}")
            return newFixedLengthResponse(
                Response.Status.SERVICE_UNAVAILABLE,
                MIME_PLAINTEXT,
                "File not ready yet"
            )
        }

        val fileLength = file.length()
        val mimeType   = mimeForFile(file.name)

        // ── Range request (MPV / ExoPlayer seeks করলে এটা আসে) ──
        val rangeHeader = session.headers["range"]
        if (rangeHeader != null && rangeHeader.startsWith("bytes=", ignoreCase = true)) {
            return try {
                val rangeSpec = rangeHeader.substring(6).trim()
                val dash      = rangeSpec.indexOf('-')
                val start     = rangeSpec.substring(0, dash).toLongOrNull() ?: 0L
                val endInclusive = if (dash < rangeSpec.length - 1)
                    minOf(rangeSpec.substring(dash + 1).toLong(), fileLength - 1)
                else
                    fileLength - 1

                // Clamp to what's actually available (torrent may still downloading)
                val available = minOf(endInclusive, file.length() - 1)
                if (available < start) {
                    // Requested range not available yet → 416
                    return newFixedLengthResponse(
                        Response.Status.RANGE_NOT_SATISFIABLE,
                        MIME_PLAINTEXT,
                        "Range not satisfiable"
                    ).also { it.addHeader("Content-Range", "bytes */$fileLength") }
                }

                val contentLength = available - start + 1

                // RandomAccessFile → skip to start, stream from there
                val raf = RandomAccessFile(file, "r")
                raf.seek(start)

                val response = newFixedLengthResponse(
                    Response.Status.PARTIAL_CONTENT,
                    mimeType,
                    FileInputStream(raf.fd),
                    contentLength
                )
                response.addHeader("Content-Range",  "bytes $start-$available/$fileLength")
                response.addHeader("Accept-Ranges",  "bytes")
                response.addHeader("Cache-Control",  "no-cache")
                response
            } catch (e: Exception) {
                Log.e(TAG, "Range serve error: ${e.message}")
                newFixedLengthResponse(
                    Response.Status.INTERNAL_ERROR,
                    MIME_PLAINTEXT,
                    "Stream error: ${e.message}"
                )
            }
        }

        // ── Full file request (HEAD or initial GET) ──
        return try {
            val response = newFixedLengthResponse(
                Response.Status.OK,
                mimeType,
                FileInputStream(file),
                fileLength
            )
            response.addHeader("Accept-Ranges", "bytes")
            response.addHeader("Cache-Control", "no-cache")
            response
        } catch (e: Exception) {
            newFixedLengthResponse(
                Response.Status.INTERNAL_ERROR,
                MIME_PLAINTEXT,
                "Stream error: ${e.message}"
            )
        }
    }

    private fun mimeForFile(name: String): String = when {
        name.endsWith(".mkv",  true) -> "video/x-matroska"
        name.endsWith(".mp4",  true) -> "video/mp4"
        name.endsWith(".avi",  true) -> "video/x-msvideo"
        name.endsWith(".mov",  true) -> "video/quicktime"
        name.endsWith(".webm", true) -> "video/webm"
        name.endsWith(".ts",   true) -> "video/mp2t"
        else                         -> "video/mp4"
    }
}
