package com.aeoncorex.streamx.ui.movie

import android.content.Context
import android.util.Log
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.isActive
import java.io.File

// ═══════════════════════════════════════════════════════════════════
//  StreamState — Torrent download/stream progress
// ═══════════════════════════════════════════════════════════════════
sealed class StreamState {
    data class Preparing(val message: String)                              : StreamState()
    data class Buffering(val progress: Int, val speed: Long, val seeds: Int, val peers: Int) : StreamState()
    /** [streamUrl] = http://127.0.0.1:8088/stream (MPV uses this directly) */
    data class Ready(val streamUrl: String)                               : StreamState()
    data class Error(val message: String)                                 : StreamState()
}

// ═══════════════════════════════════════════════════════════════════
//  TorrentEngine — JNI bridge to native libtorrent
//  ──────────────────────────────────────────────────────────────────
//  Flow logic:
//    state 0 → Preparing (connecting to DHT)
//    state 1 → Preparing (fetching metadata)
//    state 2 → Buffering (downloading pieces)
//      ↳ when progress ≥ 3% AND file path known:
//           → start TorrentStreamServer → emit Ready(httpUrl)
//           MPV এখন file copy হওয়ার আগেই HTTP stream করতে পারে
//    state 3 → Same as above (seeding/complete)
//    state 4 → Error
// ═══════════════════════════════════════════════════════════════════

object TorrentEngine {
    private const val TAG             = "StreamX_Native"
    /** HTTP stream শুরু করার minimum buffer (%) */
    private const val MIN_BUFFER_PCT  = 3

    @Volatile private var engineStopped = false
    @Volatile private var serverStarted = false

    private external fun initNative()
    private external fun startNative(magnet: String, savePath: String)
    private external fun stopNative()
    private external fun getStatusNative(): LongArray?
    private external fun getFilePathNative(): String

    init {
        try {
            System.loadLibrary("streamx-native")
            initNative()
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Native Library Load Failed: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Engine Init Failed: ${e.message}")
        }
    }

    fun start(context: Context, magnetLink: String): Flow<StreamState> = flow {
        val rootDir     = context.externalCacheDir ?: context.cacheDir
        val downloadDir = File(rootDir, "StreamX_Video")
        if (!downloadDir.exists()) downloadDir.mkdirs()

        Log.d(TAG, "Starting for: $magnetLink")

        try {
            engineStopped = false
            serverStarted = false
            startNative(magnetLink, downloadDir.absolutePath)
            emit(StreamState.Preparing("Initializing…"))

            while (currentCoroutineContext().isActive && !engineStopped) {
                val status = getStatusNative()

                if (status != null && status.size >= 5) {
                    val progress = status[0].toInt()
                    val speedKB  = status[1] / 1024
                    val seeds    = status[2].toInt()
                    val peers    = status[3].toInt()
                    val state    = status[4].toInt()

                    Log.d(TAG, "State=$state  Progress=$progress%  Speed=${speedKB}KB/s  Seeds=$seeds")

                    when (state) {
                        0 -> emit(StreamState.Preparing("Connecting to DHT…"))
                        1 -> emit(StreamState.Preparing("Fetching Metadata… ($peers peers)"))

                        2, 3 -> {
                            // ── Try to start HTTP server once we have a file path ──
                            if (!serverStarted) {
                                val path = getFilePathNative()
                                if (path.isNotEmpty() && progress >= MIN_BUFFER_PCT) {
                                    val file    = File(path)
                                    val httpUrl = TorrentStreamServer.start(file)
                                    serverStarted = true
                                    Log.d(TAG, "HTTP streaming ready at $httpUrl (${progress}% buffered)")
                                    emit(StreamState.Ready(httpUrl))
                                    return@flow
                                } else if (path.isNotEmpty()) {
                                    // Still buffering — update the server's file reference
                                    TorrentStreamServer.updateFile(File(path))
                                }
                            }
                            emit(StreamState.Buffering(progress, speedKB, seeds, peers))
                        }

                        4 -> {
                            emit(StreamState.Error("Engine error"))
                            return@flow
                        }
                    }
                }
                delay(250)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Flow error: ${e.message}")
            emit(StreamState.Error("Stream failed: ${e.message}"))
        }
    }

    /** Public accessor for TorrentStreamServer to read path during early buffering */
    fun getFilePath(): String? = try {
        val path = getFilePathNative()
        if (path.isNotEmpty()) path else null
    } catch (_: Exception) { null }

    fun stop() {
        engineStopped = true
        serverStarted = false
        TorrentStreamServer.stop()
        try { stopNative() } catch (e: Exception) { Log.e(TAG, "Stop error: ${e.message}") }
    }

    fun clearCache(context: Context) {
        try {
            val rootDir = context.externalCacheDir ?: context.cacheDir
            File(rootDir, "StreamX_Video").also { if (it.exists()) it.deleteRecursively() }
        } catch (e: Exception) {
            Log.e(TAG, "Cache clear failed")
        }
    }
}
