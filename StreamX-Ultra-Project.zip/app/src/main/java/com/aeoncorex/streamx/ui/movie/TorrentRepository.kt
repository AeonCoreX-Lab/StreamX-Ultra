package com.aeoncorex.streamx.ui.movie

import android.util.Log
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url
import java.net.URLEncoder

// --- MODELS ---
data class YtsResponse(val data: YtsData?)
data class YtsData(val movies: List<YtsMovie>?)
data class YtsMovie(val id: Int, val title: String, val torrents: List<YtsTorrent>?)
data class YtsTorrent(
    val url: String,
    val hash: String,
    val quality: String,
    val seeds: Int,
    val peers: Int,
    val size: String
)

interface YtsApi {
    @GET
    suspend fun listMovies(
        @Url url: String,
        @Query("query_term") query: String,
        @Query("limit") limit: Int = 20
    ): YtsResponse
}

object TorrentRepository {
    private val YTS_MIRRORS = listOf(
        "https://yts.mx/api/v2/list_movies.json",
        "https://yts.lt/api/v2/list_movies.json",
        "https://yts.rs/api/v2/list_movies.json"
    )

    private val api = Retrofit.Builder()
        .baseUrl("https://yts.lt/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(YtsApi::class.java)

    // FIX: Prioritize HTTP/HTTPS trackers (more reliable on many networks)
    private val TRACKERS = listOf(
        // HTTP trackers
        "http://tracker.bt4g.com:2095/announce",
        "http://tracker.files.fm:6969/announce",
        "http://tracker.gbitt.info:80/announce",
        "http://tracker.ipv6tracker.org:80/announce",
        "http://tracker.nyaa.uk:6969/announce",
        "http://tracker.zerobytes.xyz:1337/announce",
        "https://tracker.bt4g.com:443/announce",
        "https://tracker.nanoha.org:443/announce",
        // UDP trackers (backup)
        "udp://tracker.opentrackr.org:1337/announce",
        "udp://open.demonii.com:1337/announce",
        "udp://tracker.openbittorrent.com:80",
        "udp://tracker.coppersurfer.tk:6969",
        "udp://glotorrents.pw:6969/announce",
        "udp://9.rarbg.to:2710",
        "udp://tracker.torrent.eu.org:451/announce",
        "udp://tracker.internetwarriors.net:1337/announce",
        "udp://tracker.leechers-paradise.org:6969/announce",
        "udp://tracker.cyberia.is:6969/announce",
        "udp://exodus.desync.com:6969/announce",
        "udp://ipv4.tracker.harry.lu:80/announce",
        "udp://tracker.moeking.me:6969/announce",
        "udp://tracker.skynetcloud.tk:6969/announce",
        "udp://tracker.pirateparty.gr:6969/announce",
        "udp://tracker.zerobytes.xyz:1337/announce"
    )

    suspend fun getStreamLinks(
        type: MovieType,
        title: String,
        imdbId: String?,
        season: Int = 0,
        episode: Int = 0,
        isAnime: Boolean = false
    ): List<StreamLink> = withContext(Dispatchers.IO) {
        val allLinks = mutableListOf<StreamLink>()
        
        coroutineScope {
            val jobs = mutableListOf<Deferred<List<StreamLink>>>()

            if (isAnime) {
                jobs.add(async { try { TorrentProviders.fetchAnime(title, episode) } catch (e: Exception) { emptyList() } })
            }

            if (type == MovieType.SERIES && imdbId != null) {
                jobs.add(async { try { TorrentProviders.fetchSeries(imdbId, season, episode) } catch (e: Exception) { emptyList() } })
            }

            if (type == MovieType.MOVIE) {
                jobs.add(async { fetchYtsWithMirrors(imdbId, title) })
            }

            jobs.add(async {
                try {
                    val searchTitle = if(type == MovieType.SERIES) "$title S${String.format("%02d", season)}E${String.format("%02d", episode)}" else title
                    TorrentProviders.fetchBitSearch(searchTitle)
                } catch (e: Exception) { 
                    Log.e("BitSearch", "Error: ${e.message}")
                    emptyList() 
                }
            })

            jobs.awaitAll().forEach { allLinks.addAll(it) }
        }

        return@withContext allLinks
            .distinctBy { it.magnet }
            .map { link ->
                link.copy(magnet = appendTrackersToMagnet(link.magnet))
            }
            .sortedByDescending { it.seeds }
    }

    private fun appendTrackersToMagnet(magnet: String): String {
        if (!magnet.startsWith("magnet:?")) return magnet
        val trackerParams = TRACKERS.joinToString("") { "&tr=${URLEncoder.encode(it, "UTF-8")}" }
        return magnet + trackerParams
    }

    private suspend fun fetchYtsWithMirrors(imdbId: String?, title: String): List<StreamLink> {
        for (url in YTS_MIRRORS) {
            try {
                val links = fetchYtsInternal(url, imdbId, title)
                if (links.isNotEmpty()) return links 
            } catch (e: Exception) {
                continue
            }
        }
        return emptyList()
    }

    private suspend fun fetchYtsInternal(url: String, imdbId: String?, title: String): List<StreamLink> {
        var movies: List<YtsMovie>? = null

        if (!imdbId.isNullOrEmpty() && imdbId != "null") {
            val response = api.listMovies(url, imdbId)
            movies = response.data?.movies
        }

        if (movies.isNullOrEmpty()) {
            val cleanTitle = title.replace(Regex("[^a-zA-Z0-9 ]"), "")
            val response = api.listMovies(url, cleanTitle)
            movies = response.data?.movies
        }

        return movies?.flatMap { movie ->
            movie.torrents?.map { torrent ->
                StreamLink(
                    title = movie.title,
                    magnet = constructMagnet(torrent.hash, movie.title),
                    quality = torrent.quality,
                    seeds = torrent.seeds,
                    peers = torrent.peers,
                    size = torrent.size,
                    source = "YTS"
                )
            } ?: emptyList()
        } ?: emptyList()
    }

    private fun constructMagnet(hash: String, title: String): String {
        val encodedTitle = URLEncoder.encode(title, "UTF-8")
        val trackerString = TRACKERS.joinToString("") { "&tr=${URLEncoder.encode(it, "UTF-8")}" }
        return "magnet:?xt=urn:btih:$hash&dn=$encodedTitle$trackerString"
    }
}