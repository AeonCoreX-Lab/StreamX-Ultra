#include <jni.h>
#include <android/log.h>
#include <string>
#include "mpv_handler.hpp"

#define TAG "StreamX_Native"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)


// ════════════════════════════════════════════════════════════
//  MPV JNI BRIDGES
// ════════════════════════════════════════════════════════════

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_initMpvEngine(JNIEnv* env, jclass, jobject appctx) {
    init_mpv_engine(env, appctx);
}

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_playMpvVideo(JNIEnv* env, jclass, jstring path) {
    const char* fp = env->GetStringUTFChars(path, nullptr);
    play_mpv_video(fp);
    env->ReleaseStringUTFChars(path, fp);
}

// wid = GlobalRef(Java Surface) cast to int64_t — NOT ANativeWindow*
extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_setMpvSurface(JNIEnv* env, jclass, jobject surface) {
    if (g_surface_ref) { env->DeleteGlobalRef(g_surface_ref); g_surface_ref = nullptr; }
    if (surface != nullptr) {
        g_surface_ref = env->NewGlobalRef(surface);
        set_mpv_wid(reinterpret_cast<intptr_t>(g_surface_ref));
    } else {
        set_mpv_wid(0);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_setMpvSurfaceSize(JNIEnv*, jclass, jint w, jint h) {
    set_mpv_surface_size(w, h);
}

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_toggleVulkanFSR(JNIEnv*, jclass, jboolean enable) {
    toggle_vulkan_fsr(enable);
}

extern "C" JNIEXPORT jdouble JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_getMpvTime(JNIEnv*, jclass) { return get_mpv_time(); }

extern "C" JNIEXPORT jdouble JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_getMpvDuration(JNIEnv*, jclass) { return get_mpv_duration(); }

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_seekMpvVideo(JNIEnv*, jclass, jdouble sec) {
    seek_mpv_video(sec);
}

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_seekMpvAbsolute(JNIEnv*, jclass, jdouble pos) {
    seek_mpv_absolute(pos);
}

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_pauseMpvVideo(JNIEnv*, jclass, jboolean pause) {
    pause_mpv_video(pause);
}

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_commandNative(JNIEnv* env, jclass, jobjectArray arr) {
    int len = env->GetArrayLength(arr);
    const char* args[128] = {nullptr};
    for (int i = 0; i < len && i < 127; ++i) {
        auto s = (jstring)env->GetObjectArrayElement(arr, i);
        args[i] = env->GetStringUTFChars(s, nullptr);
        env->DeleteLocalRef(s);
    }
    command_mpv(args);
    for (int i = 0; i < len && i < 127; ++i) {
        auto s = (jstring)env->GetObjectArrayElement(arr, i);
        env->ReleaseStringUTFChars(s, args[i]);
        env->DeleteLocalRef(s);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_setPropertyStringNative(JNIEnv* env, jclass, jstring name, jstring value) {
    const char* n = env->GetStringUTFChars(name,  nullptr);
    const char* v = env->GetStringUTFChars(value, nullptr);
    set_property_string_mpv(n, v);
    env->ReleaseStringUTFChars(name, n); env->ReleaseStringUTFChars(value, v);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_getPropertyStringNative(JNIEnv* env, jclass, jstring name) {
    const char* n = env->GetStringUTFChars(name, nullptr);
    std::string val = get_property_string_mpv_safe(n);
    env->ReleaseStringUTFChars(name, n);
    return env->NewStringUTF(val.c_str());
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_getPropertyIntNative(JNIEnv* env, jclass, jstring name) {
    const char* n = env->GetStringUTFChars(name, nullptr);
    int64_t val = get_property_int_mpv(n);
    env->ReleaseStringUTFChars(name, n);
    return (jlong)val;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_getMpvCachePercent(JNIEnv*, jclass) { return (jint)get_cache_percent_mpv(); }

extern "C" JNIEXPORT jboolean JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_isMpvPausedForCache(JNIEnv*, jclass) { return (jboolean)(is_paused_for_cache_mpv() != 0); }

extern "C" JNIEXPORT jstring JNICALL
Java_com_aeoncorex_streamx_ui_movie_StreamXCore_getTrackListNative(JNIEnv* env, jclass, jstring type) {
    const char* t = env->GetStringUTFChars(type, nullptr);
    std::string result = get_track_list_mpv(t);
    env->ReleaseStringUTFChars(type, t);
    return env->NewStringUTF(result.c_str());
}